﻿namespace TabBlazor.Components.Tables;

public enum OnCancelStrategy {
    AsIs,
    Revert
}