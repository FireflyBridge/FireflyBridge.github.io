﻿namespace TabBlazor
{
    public enum CheckboxMode
    {
        None = 0,
        Single,
        Multiple
    }
}
