﻿namespace TabBlazor
{
    public class ModalViewSettings
    {
        public int ZIndex { get; set; }
        public int TopOffset { get; set; }
    }
}
