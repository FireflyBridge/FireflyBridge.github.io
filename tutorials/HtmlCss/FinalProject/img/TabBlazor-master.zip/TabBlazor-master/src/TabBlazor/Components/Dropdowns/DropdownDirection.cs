﻿namespace TabBlazor
{
    public enum DropdownDirection
    {
        Down, End
    }
}
