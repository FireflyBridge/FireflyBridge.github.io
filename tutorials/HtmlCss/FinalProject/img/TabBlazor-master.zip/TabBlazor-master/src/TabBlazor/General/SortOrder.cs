﻿namespace TabBlazor
{
    public enum SortOrder
    {
        Ascending,
        Descending
    }
}
