namespace TabBlazor.Components.QuickTables;

public enum Align
{
    Left,
    Center,
    Right
}