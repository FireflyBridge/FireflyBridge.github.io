namespace TabBlazor.Components.QuickTables;

public abstract partial class ColumnBase<TGridItem>
{
}
