﻿namespace TabBlazor
{
    public enum TableEditMode
    {
        Inline = 0,
        Popup = 1
    }
}
