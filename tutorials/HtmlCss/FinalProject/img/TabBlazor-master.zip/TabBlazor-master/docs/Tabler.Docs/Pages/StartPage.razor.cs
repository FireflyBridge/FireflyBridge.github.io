﻿using Microsoft.AspNetCore.Components;

namespace Tabler.Docs.Pages
{
    public partial class StartPage : ComponentBase
    {
    }
}
